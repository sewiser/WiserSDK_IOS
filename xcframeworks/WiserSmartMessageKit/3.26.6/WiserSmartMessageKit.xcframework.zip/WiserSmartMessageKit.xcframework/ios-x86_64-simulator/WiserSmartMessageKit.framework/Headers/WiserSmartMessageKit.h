//
// WiserSmartMessageKit.h
// WiserSmartMessageKit
//
// Copyright (c) 2014-2021 Wiser Inc. (https://developer.wiser.com)


#ifndef WiserSmartMessageKit_h
#define WiserSmartMessageKit_h

#import "WiserSmartMessage.h"
#import "WiserSmartMessage+WSDeprecatedApi.h"
#import "WiserSmartMessageSetting.h"

#endif /* WiserSmartMessageKit_h */
