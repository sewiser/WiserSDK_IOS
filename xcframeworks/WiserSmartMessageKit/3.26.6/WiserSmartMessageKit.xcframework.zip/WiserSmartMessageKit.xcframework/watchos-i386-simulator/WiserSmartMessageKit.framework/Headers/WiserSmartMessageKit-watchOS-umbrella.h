#ifdef __OBJC__
#import <Foundation/Foundation.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WiserSmartMessage+WSDeprecatedApi.h"
#import "WiserSmartMessage.h"
#import "WiserSmartMessageKit.h"
#import "WiserSmartMessageListModel.h"
#import "WiserSmartMessageRequestModel.h"
#import "WiserSmartMessageSetting.h"
#import "WiserSmartMessageUtils.h"

FOUNDATION_EXPORT double WiserSmartMessageKitVersionNumber;
FOUNDATION_EXPORT const unsigned char WiserSmartMessageKitVersionString[];

