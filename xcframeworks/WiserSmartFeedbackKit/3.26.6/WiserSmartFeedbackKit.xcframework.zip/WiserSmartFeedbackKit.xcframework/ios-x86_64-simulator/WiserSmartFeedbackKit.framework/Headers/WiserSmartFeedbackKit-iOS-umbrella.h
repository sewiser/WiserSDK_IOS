#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WiserSmartFeedbackItemModel.h"
#import "WiserSmartFeedbackModel.h"
#import "WiserSmartFeedbackTalkListModel.h"
#import "WiserSmartFeedbackTypeListModel.h"
#import "WiserSmartFeedback.h"
#import "WiserSmartFeedbackKit.h"

FOUNDATION_EXPORT double WiserSmartFeedbackKitVersionNumber;
FOUNDATION_EXPORT const unsigned char WiserSmartFeedbackKitVersionString[];

