//
// WiserSmartFeedbackKit.h
// WiserSmartFeedbackKit
//
// Copyright (c) 2014-2021 Wiser Inc. (https://developer.wiser.com)


/// @brief Header files for WiserSmartFeedbackKit.
#ifndef WiserSmartFeedbackKit_h
#define WiserSmartFeedbackKit_h

#import "WiserSmartFeedback.h"

#endif /* WiserSmartFeedbackKit_h */
