//
// WiserSmartTimerKit.h
// WiserSmartTimerKit
//
// Copyright (c) 2014-2021 Wiser Inc. (https://developer.wiser.com)

#ifndef WiserSmartTimerKit_h
#define WiserSmartTimerKit_h

#import "WiserSmartTimer.h"
#import "WiserSmartTimer+WSDeprecatedApi.h"

#endif /* WiserSmartTimerKit_h */
