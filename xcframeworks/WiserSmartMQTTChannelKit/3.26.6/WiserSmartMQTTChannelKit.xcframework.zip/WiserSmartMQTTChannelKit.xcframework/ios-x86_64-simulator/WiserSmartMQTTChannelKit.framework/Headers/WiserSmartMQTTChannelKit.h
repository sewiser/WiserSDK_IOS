
#ifndef WiserSmartMQTTChannelKit_h
#define WiserSmartMQTTChannelKit_h

/**
 *  当前客户端支持的最高的外网通信协议
 */
#define WISER_CURRENT_GW_PROTOCOL_VERSION 2.3

#import <WiserSmartBaseKit/WiserSmartBaseKit.h>

#import "WiserSmartMQTTChannel.h"
#import "WiserSmartMQTTConfigModel.h"

#endif
