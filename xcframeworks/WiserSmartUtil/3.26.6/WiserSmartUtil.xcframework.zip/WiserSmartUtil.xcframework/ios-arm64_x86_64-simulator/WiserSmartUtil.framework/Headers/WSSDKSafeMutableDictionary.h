//
//  WSSafeMutableDictionary.h
//  WSLibraryExample
//
//
//  Copyright © 2016年 Wiser. All rights reserved.
//

#import <Foundation/Foundation.h>

//线程安全的类
@interface WSSDKSafeMutableDictionary<KeyType, ObjectType> : NSMutableDictionary

@end

